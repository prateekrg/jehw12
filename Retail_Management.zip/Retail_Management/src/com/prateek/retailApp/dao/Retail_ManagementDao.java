package com.prateek.retailApp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.prateek.retailApp.dto.Retail_Management;

public class Retail_ManagementDao {

	public void saveDetails(Retail_Management rm) {
		Configuration cfg=new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Retail_Management.class);
		
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(rm);
		tx.commit();
		session.close();
		
		
	}

}
