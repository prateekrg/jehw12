package com.prateek.retailApp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="retail")
public class Retail_Management implements Serializable {

   @Id
   @Column(name="id")
	private int id;
   
   @Column(name="name")
	private String name;
   
   @Column(name="price")
	private double price;
   
   @Column(name="quality")
	private String quality;
   
   @Column(name="quantity")
	private int quantity;
	
	public Retail_Management() {
		System.out.println(this.getClass().getName() + " is created.....");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getQuality() {
		return quality;
	}

	public void setQuality(String quality) {
		this.quality = quality;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
