package com.prateek.retailApp.util;

import com.prateek.retailApp.dao.Retail_ManagementDao;
import com.prateek.retailApp.dto.Retail_Management;

public class Test {

	public static void main(String[] args) {
		
		Retail_Management rm=new Retail_Management();
		rm.setId(1);
		rm.setName("pen");
		rm.setPrice(50);
		rm.setQuality("good");
		rm.setQuantity(1);
		
		
		Retail_ManagementDao dao=new Retail_ManagementDao();
		dao.saveDetails(rm);
		
	}
}
