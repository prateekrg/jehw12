package com.prateek.app.application;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.prateek.app.bean.Facebook;

public class Application {

	public static void main(String[] args) {

		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Facebook fb=context.getBean(Facebook.class);
		fb.login("sam123", "ali");
		
	
	}
}
