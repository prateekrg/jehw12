package com.prateek.app.bean;

public class Internet {

	public Internet() {
		System.out.println(this.getClass().getName() + " is created.....");
	}
	
	public void connect(String name)
	{
		System.out.println("welcome..."+name);
	}
	
	
}
