package com.prateek.app.bean;

public class Facebook {

	Internet internet;
	
	public Facebook() {
		System.out.println(this.getClass().getName() + " is created.....");
	}
	
	public void login(String username,String password)
	{
		if(internet!=null)
		{
			internet.connect(username);
		}else{
			System.out.println("internet is not connected....");
		}
	}

	public Internet getInternet() {
		return internet;
	}

	public void setInternet(Internet internet) {
		this.internet = internet;
	}
	
	
}
