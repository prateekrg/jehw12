package com.prateek.app.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.prateek.app.dto.Student;
import com.prateek.utilApp.HibernateUtil;

public class StudentBackLogDao {

	public void saveDetails(Student s) {
		Session session=HibernateUtil.getSessionFactory().openSession();
		Transaction tx=session.beginTransaction();
		try {
			session.save(s);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		}finally{
			session.close();
		}
		System.out.println("----saved-----");
		
		
	}

}
