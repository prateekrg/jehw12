package com.prateek.app.dto;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Student {

	
	@Id
	@GenericGenerator(name="student_id_seq",strategy="increment")
	@GeneratedValue(generator="student_id_seq")
	private int id;
	private String name;
	private String branch;
	private String sem;
	private int noOfBacks;
	private double fees;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,targetEntity=Backlogs.class,mappedBy="student")
	@PrimaryKeyJoinColumn
	private Collection<Backlogs>  backlogs;
	public Student() {
		System.out.println(this.getClass().getSimpleName()+" is created....");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public String getSem() {
		return sem;
	}

	public void setSem(String sem) {
		this.sem = sem;
	}

	public int getNoOfBacks() {
		return noOfBacks;
	}

	public void setNoOfBacks(int noOfBacks) {
		this.noOfBacks = noOfBacks;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public Collection<Backlogs> getBacklogs() {
		return backlogs;
	}

	public void setBacklogs(Collection<Backlogs> backlogs) {
		this.backlogs = backlogs;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	
	
}
