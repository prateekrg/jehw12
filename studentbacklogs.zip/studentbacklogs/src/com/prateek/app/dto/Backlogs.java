package com.prateek.app.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Backlogs {

	@Id
	@GenericGenerator(name="backlogs_id_seq",strategy="increment")
	@GeneratedValue(generator="backlogs_id_seq")
	private int id;
	private String sub;
	private String sem;
	private String subcode;
	private double backlogFees;
	private int noOfAttempts;
	@ManyToOne
	@JoinColumn(name="s_id")
	private Student student;
	
	public Backlogs() {
		System.out.println(this.getClass().getSimpleName()+"  is created....");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSub() {
		return sub;
	}

	public void setSub(String sub) {
		this.sub = sub;
	}

	public String getSem() {
		return sem;
	}

	public void setSem(String sem) {
		this.sem = sem;
	}

	public String getSubcode() {
		return subcode;
	}

	public void setSubcode(String subcode) {
		this.subcode = subcode;
	}

	public double getBacklogFees() {
		return backlogFees;
	}

	public void setBacklogFees(double backlogFees) {
		this.backlogFees = backlogFees;
	}

	public int getNoOfAttempts() {
		return noOfAttempts;
	}

	public void setNoOfAttempts(int noOfAttempts) {
		this.noOfAttempts = noOfAttempts;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
	
	
}
