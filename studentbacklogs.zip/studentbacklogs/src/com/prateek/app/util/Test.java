package com.prateek.app.util;

import java.util.ArrayList;
import java.util.Collection;

import com.prateek.app.dao.StudentBackLogDao;
import com.prateek.app.dto.Backlogs;
import com.prateek.app.dto.Student;

public class Test {

	public static void main(String[] args) {
		Student s=new Student();
		s.setName("manohar");
		s.setBranch("is");
		s.setSem("4th");
		s.setNoOfBacks(11);
		s.setFees(600000);
		
		Backlogs back1=new Backlogs();
		back1.setSub("flat");
		back1.setSem("4th");
		back1.setSubcode("flat@123");
		back1.setBacklogFees(400);
		back1.setNoOfAttempts(3);
		back1.setStudent(s);
		
		Backlogs back2=new Backlogs();
		back2.setSub("oomd");
		back2.setSem("7th");
		back2.setSubcode("oomd@456");
		back2.setBacklogFees(400);
		back2.setNoOfAttempts(5);
		back2.setStudent(s);
		
		
		Collection<Backlogs> col=new ArrayList<Backlogs>();
		col.add(back1);
		col.add(back2);
		
		s.setBacklogs(col);
		
		StudentBackLogDao dao=new StudentBackLogDao();
		dao.saveDetails(s);
		
		
		
		
	}
}
