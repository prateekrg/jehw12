package com.prateek.mvc.service;

import com.prateek.mvc.dto.RegisterDto;

public interface RegisterService {

	String saveDetails(RegisterDto dto);

}
