package com.prateek.mvc.service;

public interface LoginService {

	boolean checkLogin(String name, String password);

}
