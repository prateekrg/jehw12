package com.prateek.mvc.daoImpl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.prateek.utilApp.HibernateUtil;
import org.springframework.stereotype.Repository;

import com.prateek.mvc.dao.LoginDao;

@Repository
public class LoginDaoImpl implements LoginDao{

	@Override
	public boolean checkLogin(String name, String password) {
	Session session=HibernateUtil.getSessionFactory().openSession();
	Query syntx=session.getNamedQuery("RegisterDto.checkLogin");
	syntx.setParameter("nm", name);
	syntx.setParameter("pwd", password);
	
	String username=(String) syntx.uniqueResult();
	if(username !=null){
		return true;
	}else{
		return false;
	}
		
	}

}
