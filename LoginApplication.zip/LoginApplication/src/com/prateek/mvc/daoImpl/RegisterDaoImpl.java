package com.prateek.mvc.daoImpl;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.prateek.utilApp.HibernateUtil;
import org.springframework.stereotype.Repository;

import com.prateek.mvc.dao.RegisterDao;
import com.prateek.mvc.dto.RegisterDto;
@Repository
public class RegisterDaoImpl implements RegisterDao
{

	@Override
	public String saveDetails(RegisterDto dto) {
	Session session=HibernateUtil.getSessionFactory().openSession();
	Transaction tx=session.beginTransaction();
	try {
		session.save(dto);
		tx.commit();
		return "success";
	} catch (Exception e) {
		tx.rollback();
		e.printStackTrace();
		return "error";
	}
	}

}
