package com.prateek.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.prateek.mvc.service.LoginService;

@Controller
@RequestMapping("/")
public class LoginController {

	@Autowired
	private LoginService service;
	
	@RequestMapping(value="/login.do" ,method={RequestMethod.GET,RequestMethod.POST})
	public String login(HttpServletRequest request)
	{
		
		System.out.println("inside login controller...");	
		String name=request.getParameter("username");
		String password=request.getParameter("password");

		boolean status=service.checkLogin(name,password);
		if(status){
			
			return "/loginSuccess.jsp";
		}
		else{
			return "/loginError.jsp";
		}
	}
	
}
