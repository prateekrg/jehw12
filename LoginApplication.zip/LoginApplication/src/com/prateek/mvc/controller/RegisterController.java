package com.prateek.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.prateek.mvc.dto.RegisterDto;
import com.prateek.mvc.service.RegisterService;
import com.prateek.mvc.serviceImpl.RegisterServiceImpl;
@Controller
@RequestMapping("/")
public class RegisterController {

	@Autowired
	private RegisterService service;
	
	@RequestMapping(value="/register.do" ,method={RequestMethod.GET,RequestMethod.POST})
	public String register(@ModelAttribute RegisterDto dto,HttpServletRequest request)
	{
		
		System.out.println("inside controller.....");
		String status=service.saveDetails(dto);
		
		if(status.equalsIgnoreCase("success"))
		{
			request.setAttribute("name", dto.getUsername());
			return "/registerSuccess.jsp";
		}else{
			return "/registerError.jsp";
		}
	}
}
