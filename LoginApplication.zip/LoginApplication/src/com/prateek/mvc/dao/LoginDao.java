package com.prateek.mvc.dao;

public interface LoginDao {

	boolean checkLogin(String name, String password);

}
