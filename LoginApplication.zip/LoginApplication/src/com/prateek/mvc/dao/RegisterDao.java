package com.prateek.mvc.dao;

import com.prateek.mvc.dto.RegisterDto;

public interface RegisterDao {

	String saveDetails(RegisterDto dto);

}
