package com.prateek.mvc.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prateek.mvc.dao.RegisterDao;
import com.prateek.mvc.dto.RegisterDto;
import com.prateek.mvc.service.RegisterService;
@Service
public class RegisterServiceImpl  implements RegisterService{

	@Autowired
	private RegisterDao dao;
	
	@Override
	public String saveDetails(RegisterDto dto) {
		
		return dao.saveDetails(dto) ;
	}

}
