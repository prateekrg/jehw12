package com.prateek.mvc.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prateek.mvc.dao.LoginDao;
import com.prateek.mvc.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService {

	
	@Autowired
	private LoginDao dao;
	
	@Override
	public boolean checkLogin(String name, String password) {
		
		return dao.checkLogin(name,password);
	}

}
