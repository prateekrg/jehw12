package com.prateek.app.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Petrol {

	@Id
	@GenericGenerator(name="petrol_id_seq",strategy="increment")
	@GeneratedValue(generator="petrol_id_seq")
	private int id;
	private double price;
	private double density;
	public Bike getBike() {
		return bike;
	}

	public void setBike(Bike bike) {
		this.bike = bike;
	}

	private String type;
	
	@OneToOne
	@JoinColumn
	private Bike bike;
	
	public Petrol() {
	   System.out.println(this.getClass().getSimpleName()+" is created...");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getDensity() {
		return density;
	}

	public void setDensity(double density) {
		this.density = density;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
	
}
