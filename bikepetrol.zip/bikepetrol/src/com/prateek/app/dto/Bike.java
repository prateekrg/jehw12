package com.prateek.app.dto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Bike {

	@Id
	@GenericGenerator(name="bike_id_seq",strategy="increment")
	@GeneratedValue(generator="bike_id_seq")
	private int id;
	private double cc;
	private String model;
	private String colour;
	private double price;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@PrimaryKeyJoinColumn
	private Petrol petrol;
	
	public Petrol getPetrol() {
		return petrol;
	}

	public void setPetrol(Petrol petrol) {
		this.petrol = petrol;
	}

	public Bike() {
	  System.out.println(this.getClass().getSimpleName()+"  is created....");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getCc() {
		return cc;
	}

	public void setCc(double cc) {
		this.cc = cc;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
