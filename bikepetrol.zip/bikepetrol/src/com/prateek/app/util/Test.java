package com.prateek.app.util;

import com.prateek.app.dao.BikePetrolDao;
import com.prateek.app.dto.Bike;
import com.prateek.app.dto.Petrol;

public class Test {

	public static void main(String[] args) {
		
		Bike b1=new Bike();
		b1.setCc(200);
		b1.setModel("NS");
		b1.setColour("black");
		b1.setPrice(170000);
		
		
		Petrol p=new Petrol();
		p.setPrice(75);
		p.setDensity(0.77);
		p.setType("power");
		
		b1.setPetrol(p);
		p.setBike(b1);
		
		BikePetrolDao dao=new BikePetrolDao();
		dao.saveDetails(b1);
		
		
	}
	
}
