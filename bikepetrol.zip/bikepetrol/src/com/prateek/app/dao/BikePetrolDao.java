package com.prateek.app.dao;


import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jehm12.Hibernate.HibernateUtil;
import com.prateek.app.dto.Bike;

public class BikePetrolDao {

	public void saveDetails(Bike b1) {
		System.out.println("---saving---");
		Session session=HibernateUtil.getSessionFactory().openSession();
		Transaction tx=session.beginTransaction();
		try {
			session.save(b1);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}finally {
			session.close();
		}
		System.out.println("---saved-----");
		
				
		
	}

}
