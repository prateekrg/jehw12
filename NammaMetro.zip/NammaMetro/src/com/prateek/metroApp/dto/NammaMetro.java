package com.prateek.metroApp.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

import javassist.bytecode.stackmap.TypeData.ClassName;

@Entity
public class NammaMetro {

	@Id
	@GenericGenerator(name="Nammametro_id_seq" ,strategy="increment")
	@GeneratedValue(generator="Nammametro_id_seq")
	private int id;
	private  int trainno;
	private String route;
	private String timings;
	private String colour;
	private double price;
	
	public NammaMetro() {
		System.out.println(this.getClass().getName() + " is created...");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTrainno() {
		return trainno;
	}

	public void setTrainno(int trainno) {
		this.trainno = trainno;
	}

	public String getRoute() {
		return route;
	}

	public void setRoute(String route) {
		this.route = route;
	}

	public String getTimings() {
		return timings;
	}

	public void setTimings(String timings) {
		this.timings = timings;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
}
