package com.prateek.metroApp.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.prateek.metroApp.dto.NammaMetro;
import com.prateek.utilApp.HibernateUtil;

public class NammaMetroDao {

	public void save(NammaMetro n1) {
		System.out.println("----saving details-----");
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		session.save(n1);
		tx.commit();
		session.close();
		System.out.println(" ----details saved-----");

	}

	public long getTotalCount() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		String qry = "select count(*) from NammaMetro";
		Query syntx = session.createQuery(qry);
		long count = (long) syntx.uniqueResult();
		return count;
	}

	public String getRouteByColour(String colour) {
Session session=HibernateUtil.getSessionFactory().openSession();
String  syntx="select n.route from NammaMetro n where n.colour='"+colour+"'     ";
		Query qry=session.createQuery(syntx);
		String route=(String) qry.uniqueResult();
		return route;
	}

	public double getPriceByTrainNo(int trainno) {

		Session session=HibernateUtil.getSessionFactory().openSession();
		String syntx="select m.price from NammaMetro m where m.trainno= "+trainno+"  ";
		
		Query qry=session.createQuery(syntx);
		double price=(double) qry.uniqueResult();
		return price;
	}

	public void updateTimingsByTrainno(String timings, int trainno) {
	System.out.println("updating details.......");
	Session session=HibernateUtil.getSessionFactory().openSession();
	
	Query qry=session.getNamedQuery("NammaMetro.updateTimingsByTrainno");
	qry.setParameter("tm",timings);
	qry.setParameter("tn", trainno);
	qry.executeUpdate();
	session.close();
	
	System.out.println("updated successfully.......");
	}

	public void deleteNammaMetroByTrainno(int trainno) {
		System.out.println("deleting details.......");
		Session session=HibernateUtil.getSessionFactory().openSession();
		
		Query qry=session.getNamedQuery("NammaMetro. deleteNammaMetroByTrainno");
		qry.setParameter("tn", trainno);
		qry.executeUpdate();
		session.close();
		System.out.println("deleted successfully.......");
		
	}

	public List<NammaMetro> fetchAllDetails() {
		Session session=HibernateUtil.getSessionFactory().openSession();
		
		Query qry=session.getNamedQuery("NammaMetro.fetchAllDetails");
		List<NammaMetro> data=qry.list();
		
		session.close();
		return data;
	}
	
}
