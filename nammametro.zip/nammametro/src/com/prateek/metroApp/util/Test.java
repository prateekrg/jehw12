package com.prateek.metroApp.util;

import java.util.Iterator;
import java.util.List;

import com.prateek.metroApp.dao.NammaMetroDao;
import com.prateek.metroApp.dto.NammaMetro;

public class Test {
	public static void main(String[] args) {

	NammaMetro n1=new NammaMetro();
	n1.setTrainno(1235);
	n1.setRoute("yeswanthpur to raajinagar");
	n1.setTimings("10oclock");
	n1.setColour("purple");
   n1.setPrice(35);			
	
	NammaMetroDao dao=new NammaMetroDao();
	//dao.save(n1);
	
	/*long count=dao.getTotalCount();
	System.out.println("total no of records: "+count);

	String route=dao.getRouteByColour("green");
	System.out.println("Route Is :"+route);*/
	
	/*double price=dao.getPriceByTrainNo(1234);
	System.out.println("Price is :"+price);
	*/
	
//	dao.updateTimingsByTrainno("11oclock",1234);
	//dao.deleteNammaMetroByTrainno(1234);
	List<NammaMetro> list=dao.fetchAllDetails();
	
	Iterator<NammaMetro> i=list.iterator();
	while (i.hasNext()) {
		NammaMetro nammaMetro = (NammaMetro) i.next();
		System.out.println(nammaMetro.getColour()+"\t"+nammaMetro.getPrice());
	}
	
	}
}
