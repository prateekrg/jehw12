package com.prateek.voteApp.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.DispatcherServlet;

import com.prateek.voteApp.dto.VoterDto;

@Component
@RequestMapping("/")
public class VotingController {

	
	/*@RequestMapping(value="/vote.do",method={RequestMethod.GET,RequestMethod.POST})
	public String vote(HttpServletRequest request)
	{
		
		
		String voterId=request.getParameter("voterId");
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		String dob=request.getParameter("dob");
		String place=request.getParameter("place");
		String party=request.getParameter("party");
		
		
		System.out.println("voterId..."+voterId);
		System.out.println("name..."+name);
		System.out.println("address..."+address);
		System.out.println("dob..."+dob);
		System.out.println("place..."+place);
		System.out.println("party..."+party);
		
		
		request.setAttribute("party", party);
		
		return "/success.jsp";
	}*/
/*
	@RequestMapping(value="/vote.do",method={RequestMethod.GET,RequestMethod.POST})
	public String vote(@RequestParam("voterId")String voterId,
			@RequestParam("name")String name,
			@RequestParam("address")String address,
			@RequestParam("dob")String dob,
			@RequestParam("place")String place,
			@RequestParam("party")String party,
			HttpServletRequest request)
	{
		
		System.out.println("voterId..."+voterId);
		System.out.println("name..."+name);
		System.out.println("address..."+address);
		System.out.println("dob..."+dob);
		System.out.println("place..."+place);
		System.out.println("party..."+party);
		
		
		request.setAttribute("party", party);
		
		return "/success.jsp";
	}
	*/
   @RequestMapping(value="/vote.do",method={RequestMethod.GET,RequestMethod.POST})
	public String vote(@ModelAttribute VoterDto dto,HttpServletRequest request)
	{
		
		request.setAttribute("party", dto.getParty());
		
		return "/success.jsp";
	}
	
	
}
