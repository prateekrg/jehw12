package com.prateek.cricApp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.prateek.cricApp.dto.Cricket;
import com.prateek.utilApp.HibernateUtil;

public class CricketDao {

	public void saveCricDetails(Cricket c1) {

		Session session =HibernateUtil.getSessionFactory().openSession(); 
		Transaction tx = session.beginTransaction();
		session.save(c1);
		tx.commit();
		session.close();
	}

	public Cricket getTeamDetailsBypk(int pk) {

		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Cricket.class);

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Cricket c1 = session.get(Cricket.class, pk);
		session.close();
		return c1;
	}

	public void updateTeamByPk(int pk, String teamName) {
		System.out.println("updating deatils.......");
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Cricket.class);

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		Cricket c = session.get(Cricket.class, pk);
		c.setTeamName(teamName);
		session.update(c);
		tx.commit();
		session.close();
		System.out.println("deatils updated.......");
	}

	public void deleteTeamByPk(int pk) {

		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Cricket.class);

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		Cricket c = session.get(Cricket.class, pk);

		session.delete(c);
		tx.commit();
		session.close();
		System.out.println("deleted successfully.......");
	}

}
