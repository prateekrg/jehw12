package com.prateek.cricApp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="cricket")
public class Cricket  {

	@Id
	@GenericGenerator(name="cricket_id_seq",strategy="increment")
	@GeneratedValue(generator="cricket_id_seq")
	@Column(name="id")
	private int id;
	
	@Column(name="teamName")
	private String teamName;
	
	@Column(name="captain")
	private String captain;
	
	@Column(name="coach")
	private String coach;
	
	@Column(name="keeper")
	private String keeper;
	
	@Column(name="viceCaptain")
	private String viceCaptain;

	public Cricket() {
		System.out.println(this.getClass().getName() + " is created.....");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getCaptain() {
		return captain;
	}

	public void setCaptain(String captain) {
		this.captain = captain;
	}

	public String getCoach() {
		return coach;
	}

	public void setCoach(String coach) {
		this.coach = coach;
	}

	public String getKeeper() {
		return keeper;
	}

	public void setKeeper(String keeper) {
		this.keeper = keeper;
	}

	public String getViceCaptain() {
		return viceCaptain;
	}

	public void setViceCaptain(String viceCaptain) {
		this.viceCaptain = viceCaptain;
	}

	
}
