package com.prateek.cricApp.util;

import com.prateek.cricApp.dao.CricketDao;
import com.prateek.cricApp.dto.Cricket;

public class Test {

	public static void main(String[] args) {
		Cricket c1=new Cricket();
		
		
		c1.setTeamName("Delhi");
		c1.setCaptain("Kohli");
		c1.setCoach("gary Karstron");
		c1.setKeeper("de kock");
		c1.setViceCaptain("ABD");
		
		CricketDao dao=new CricketDao();
		dao.saveCricDetails(c1);
		
	}
}
