package com.prateek.app.application;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.prateek.app.bean.Pen;

public class Application {

	public static void main(String[] args) {
		ApplicationContext container=new ClassPathXmlApplicationContext("spring.xml");
		Pen renolds=container.getBean("parker",Pen.class);
		renolds.display();
	}
}
