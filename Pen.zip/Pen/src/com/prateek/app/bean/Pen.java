package com.prateek.app.bean;

public class Pen {

	String colour;
	double price;
	public Pen(double price) {
		this.price=price;
		System.out.println("Calling double-arg constructor...");
	}
	public Pen(String colour) {
		this.colour=colour;
		System.out.println("Calling string-arg constructor...");
	}
	
	public void display()
	{
		System.out.println(colour+"\t"+price);
	}
}
