package com.prateek.app.trainer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Trainer {

	private int t_id;
	private String t_name;
	
	public Trainer() {
		System.out.println(this.getClass().getName() + " is created.....");
	}

	public int getT_id() {
		return t_id;
	}

	@Value("40")
	public void setT_id(int t_id) {
		this.t_id = t_id;
	}

	public String getT_name() {
		return t_name;
	}

	@Value("Pavana")
	public void setT_name(String t_name) {
		this.t_name = t_name;
	}
	
	
	
}
