package com.prateek.app.workers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Worker {

	private int w_id;
	private String w_name;
	@Autowired
	public Worker(@Value("20")int w_id,@Value("pooja")String w_name) {
		this.w_id=w_id;
		this.w_name=w_name;

	}

	public int getW_id() {
		return w_id;
	}

	public void setW_id(int w_id) {
		this.w_id = w_id;
	}

	public String getW_name() {
		return w_name;
	}

	public void setW_name(String w_name) {
		this.w_name = w_name;
	}
	
	
	
}
