package com.prateek.app.application;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.prateek.app.Student.Student;
import com.prateek.app.trainer.Trainer;
import com.prateek.app.workers.Worker;

public class Application {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Student s1=context.getBean(Student.class);
		System.out.println(s1.getId());
		System.out.println(s1.getName());
		
		
		Trainer t1=context.getBean(Trainer.class);
		System.out.println(t1.getT_id());
		System.out.println(t1.getT_name());
		
		Worker w1=context.getBean(Worker.class);
		
		System.out.println(w1.getW_id());
		System.out.println(w1.getW_name());
		
	}
}
